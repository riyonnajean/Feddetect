package com.example.fed;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class ScanActivity extends AppCompatActivity {

    AlertDialog.Builder builder;
    FeatureExtractor featureExtractor;
    TFLiteMalwareDetector malwareDetector;
    boolean modelUpdated = false;  // Flag to track if the model is updated

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);

        // Initialize AlertDialog builder and FeatureExtractor
        builder = new AlertDialog.Builder(this);
        featureExtractor = new FeatureExtractor(this);

        // Load TFLite model
        try {
            malwareDetector = new TFLiteMalwareDetector(this);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error loading ML model.", Toast.LENGTH_LONG).show();
            return;
        }

        // Find the Scan button in the layout
        Button scanButton = findViewById(R.id.scan_button);

        // Set up button click listener
        scanButton.setOnClickListener(view -> {
            // Show "Scanning started" toast
            Toast.makeText(ScanActivity.this, "Scanning all installed APKs...", Toast.LENGTH_SHORT).show();

            // Scan all APKs and detect malware
            scanAndDetectMalware();
        });
    }

    // Scan and detect malware in installed apps
    private void scanAndDetectMalware() {
        try {
            PackageManager packageManager = getPackageManager();
            List<ApplicationInfo> installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);

            StringBuilder malwareApps = new StringBuilder();
            int malwareCount = 0;

            for (ApplicationInfo appInfo : installedApps) {
                try {
                    String packageName = appInfo.packageName;

                    // Extract features using FeatureExtractor
                    float[] features = featureExtractor.extractFeatures(packageName);

                    // Predict using the trained TFLite model
                    float prediction = malwareDetector.predict(features);

                    // Check if the app is flagged as malware
                    if (prediction > 0.5) {
                        malwareApps.append(packageName).append("\n");
                        malwareCount++;

                        // Log the detection data (features and result)
                        malwareDetector.logDetectionData(features, true);

                        // Save the prediction output to a file
                        File predictionFile = new File(getFilesDir(), "prediction_output.txt");
                        malwareDetector.savePredictionOutput(predictionFile, prediction);

                        // Mark the model as updated
                        modelUpdated = true;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            // If any updates were made to the model, save the updated model
            if (modelUpdated) {
                File updatedModelFile = new File(getFilesDir(), "updated_model.tflite");
                malwareDetector.saveUpdatedModel(updatedModelFile);

                // Send the updated model to the server (simulated)
                sendUpdatedModelToServer(updatedModelFile);

                // Show alert that model has been updated
                showAlert("Model Updated", "Malware detected and model updated.");
            } else {
                // If no new malware detected, notify the user
                showAlert("No Updates", "No malware detected, model remains unchanged.");
            }

            // Show results in AlertDialog
            String resultMessage = malwareCount > 0
                    ? "Malware detected in the following apps:\n" + malwareApps
                    : "No malware detected in installed APKs.";
            showAlert("Scan Completed", resultMessage);

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Failed to scan installed APKs.");
        }
    }

    // Send the updated model to the server (simulated)
    private void sendUpdatedModelToServer(File modelFile) {
        // Implement the actual upload logic here (e.g., using Retrofit, OkHttp)
        Toast.makeText(this, "Updated model sent to server.", Toast.LENGTH_SHORT).show();
    }

    // Function to show alert dialog with scan results
    private void showAlert(String title, String message) {
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .create()
                .show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (malwareDetector != null) {
            malwareDetector.close();
        }
    }
}
