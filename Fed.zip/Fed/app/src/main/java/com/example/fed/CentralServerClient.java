package com.example.fed;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import java.io.File;
import java.io.IOException;

public class CentralServerClient {

    private static final String SERVER_URL = "http://192.168.187.13:5000/upload_model"; // Flask server URL to upload model
    private OkHttpClient client;

    public CentralServerClient() {
        client = new OkHttpClient(); // Initialize the OkHttp client
    }

    // Method to send the updated model file to the server
    public void sendUpdatedModelToServer(File modelFile, Callback callback) {
        // Create the request body with the model file
        RequestBody fileBody = RequestBody.create(MediaType.parse("application/octet-stream"), modelFile);

        MultipartBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", modelFile.getName(), fileBody) // Attach the file
                .build();

        // Create the request object
        Request request = new Request.Builder()
                .url(SERVER_URL) // Flask server URL
                .post(requestBody) // Sending a POST request with the model file
                .build();

        // Make the network call asynchronously
        client.newCall(request).enqueue(callback); // Callback to handle the response
    }

    // Method to receive the aggregated model back from the server
    public void receiveAggregatedModelFromServer(Callback callback) {
        // Create the request object for receiving the model
        Request request = new Request.Builder()
                .url(SERVER_URL) // Flask server URL to get the aggregated model
                .get() // Sending a GET request to receive the model
                .build();

        // Make the network call asynchronously
        client.newCall(request).enqueue(callback); // Callback to handle the response
}
}
