package com.example.fed;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class Homepage extends AppCompatActivity {
    private ProgressBar progressBar;
    private Button connectButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

        progressBar = findViewById(R.id.progressBar);
        connectButton = findViewById(R.id.button1);

        // Set initial color to white (Progress Bar color)
        progressBar.setProgressTintList(getResources().getColorStateList(android.R.color.white));

        progressBar.setVisibility(View.INVISIBLE);  // Hide progress bar initially

        // Set click listener for the button
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Show the progress bar when the button is clicked
                progressBar.setVisibility(View.VISIBLE);

                // Reset the progress to 0% before starting
                progressBar.setProgress(0);

                // Simulate connection process with a new thread
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        boolean connectionSuccess = attemptConnection();  // Simulate connection attempt

                        // Update the progress bar and handle result
                        for (int progress = 0; progress <= 100; progress++) {
                            // Update progress bar
                            progressBar.setProgress(progress);

                            // If progress reaches 100%, change the progress bar color to blue
                            if (progress == 100) {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressBar.setProgressTintList(getResources().getColorStateList(R.color.colorPrimary)); // Set to blue
                                    }
                                });
                            }

                            try {
                                Thread.sleep(50);  // Simulate time-consuming task (e.g., connecting to server)
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }

                        // Once the progress is complete, handle the result
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (connectionSuccess) {
                                    Toast.makeText(Homepage.this, "Connection Established!", Toast.LENGTH_SHORT).show();
                                }

                                // Hide the progress bar after completion
                                progressBar.setVisibility(View.INVISIBLE);
                            }
                        });
                    }
                }).start();
            }
        });
    }

    // Simulate the connection attempt (this can be replaced with actual network logic)
    private boolean attemptConnection() {
        try {
            Thread.sleep(1000); // Simulate some delay in the connection process
            // Simulate a random result (either successful or failed)
            return Math.random() < 0.5;  // 50% chance of success
        } catch (InterruptedException e) {
            e.printStackTrace();
            return false;
        }
    }
}
