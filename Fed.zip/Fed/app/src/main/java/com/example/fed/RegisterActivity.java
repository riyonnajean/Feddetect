package com.example.fed;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.inputmethod.EditorInfo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class RegisterActivity extends AppCompatActivity {
    EditText edRegUsername, edRegPassword, edRegEmail, edRegConfirmPassword;
    Button btn;
    TextView tv, tv2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Make the activity full-screen (edge-to-edge)
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );

        // Initialize views
        edRegUsername = findViewById(R.id.editTextRegUsername);
        edRegPassword = findViewById(R.id.editTextRegPassword);
        edRegEmail = findViewById(R.id.editTextRegEmail);
        edRegConfirmPassword = findViewById(R.id.editTextRegConfirmPassword);
        btn = findViewById(R.id.buttonRegLogin);
        tv = findViewById(R.id.textViewRegistration);
        tv2 = findViewById(R.id.textViewExist);

        // Editor action listener for the email field
        edRegEmail.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO) { // Ensure actionGo is set in XML
                Toast.makeText(getApplicationContext(), "Go button pressed!", Toast.LENGTH_SHORT).show();
                return true; // Action handled
            }
            return false; // Action not handled
        });

        // Apply insets for system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Button click listener
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Retrieve input from EditText fields
                String username = edRegUsername.getText().toString();
                String password = edRegPassword.getText().toString();
                String email = edRegEmail.getText().toString();
                String confirm = edRegConfirmPassword.getText().toString();

                // Validate input
                if (username.isEmpty() || password.isEmpty() || email.isEmpty() || confirm.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Enter All Details!", Toast.LENGTH_SHORT).show();
                } else {
                    if (password.compareTo(confirm) == 0) {
                        if (isValid(password)) {
                            Toast.makeText(getApplicationContext(), "Record Inserted", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this, Homepage.class));
                        } else {
                            Toast.makeText(getApplicationContext(), "The password should contain at least 8 characters!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "The password is incorrect!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // Redirect to LogoActivity when 'textViewExist' is clicked
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegisterActivity.this, LogoActivity.class));
            }
        });
    }

    // Password validation function (checks length and character types)
    public static boolean isValid(String passwordhere) {
        boolean hasLetter = false;
        boolean hasDigit = false;
        boolean hasSpecialChar = false;

        if (passwordhere.length() < 8) {
            return false; // Password too short
        }

        for (char c : passwordhere.toCharArray()) {
            if (Character.isLetter(c)) {
                hasLetter = true;
            } else if (Character.isDigit(c)) {
                hasDigit = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecialChar = true;
            }

            // Break early if all conditions are met
            if (hasLetter && hasDigit && hasSpecialChar) {
                return true;
            }
        }

        return hasLetter && hasDigit && hasSpecialChar;
    }
}
